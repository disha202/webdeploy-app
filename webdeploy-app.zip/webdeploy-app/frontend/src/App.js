import React from "react";

function App() {
  return (
    <div>
      <h1>WebDeploy</h1>
      <p>Upload your static site and get a live URL instantly!</p>
      <button>Upload</button>
    </div>
  );
}

export default App;
