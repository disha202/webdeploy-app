const express = require("express");
const app = express();
app.use(express.json());

app.post("/deploy", (req, res) => {
  res.json({ url: "https://dummy-deployment.com/123" });
});

app.listen(5000, () => console.log("Backend running on port 5000"));
