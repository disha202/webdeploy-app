# WebDeploy - Project Plan
- Users can upload static sites or GitHub repo links.
- Backend deploys to Netlify/AWS S3.
- Dashboard shows deployed sites + status.
